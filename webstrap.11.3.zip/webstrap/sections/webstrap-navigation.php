	<!-- Header Widget Info -->
	<div class="header-widget-info d-none d-lg-block">
	    <div class="container">
	    	<div class="row">
	    		<div class="col-md-12">
		            <div class="header-wrapper">
		                <div class="brand-logo">
		                    <div class="logo">
		                    	<?php
	                            if(has_custom_logo()) {
	                                the_custom_logo();
	                            }
	                            else { ?>
	                            	<a href="<?php echo esc_url(home_url( '/' )); ?>" class="navbar-brand">
	                            		<?php echo esc_html(get_bloginfo('name')); ?>
	                            	</a>
	                            <?php }
	                            $webstrap_description = get_bloginfo( 'description');
	                            if ($webstrap_description) : ?>
	                                <p class="site-description"><?php echo esc_html($webstrap_description); ?></p>
	                            <?php endif; ?>
		                    </div>
		                </div>
		                <div class="header-right">
		                    <div class="header-info">
								<?php 
									$webstrap_hs_nav_contact_info	= get_theme_mod('hs_nav_contact_info','1');
									$webstrap_nav_ct_info1_icon		= get_theme_mod('nav_ct_info1_icon','fa-clock-o');
									$webstrap_nav_ct_info1_ttl		= get_theme_mod('nav_ct_info1_ttl');
									$webstrap_nav_ct_info1_subttl	= get_theme_mod('nav_ct_info1_subttl');
									$webstrap_nav_ct_info2_icon		= get_theme_mod('nav_ct_info2_icon','fa-phone');
									$webstrap_nav_ct_info2_ttl		= get_theme_mod('nav_ct_info2_ttl');
									$webstrap_nav_ct_info2_subttl	= get_theme_mod('nav_ct_info2_subttl');
									$webstrap_nav_ct_info3_icon		= get_theme_mod('nav_ct_info3_icon','fa-clock-o');
									$webstrap_nav_ct_info3_ttl		= get_theme_mod('nav_ct_info3_ttl');
									$webstrap_nav_ct_info3_subttl	= get_theme_mod('nav_ct_info3_subttl');
									if($webstrap_hs_nav_contact_info =='1'){
								?>
							    <div class="header-carousel">
							       <?php if(!empty($webstrap_nav_ct_info1_icon) || !empty($webstrap_nav_ct_info1_ttl) || !empty($webstrap_nav_ct_info1_subttl)): ?>
										<div class="widget widget_contact widget_first">
											<div class="contact-area">
												<?php if(!empty($webstrap_nav_ct_info1_icon)): ?>
													<div class="contact-icon"><i class="fa <?php echo esc_attr($webstrap_nav_ct_info1_icon); ?>"></i></div>
												<?php endif; ?>
												
												<?php if(!empty($webstrap_nav_ct_info1_ttl) || !empty($webstrap_nav_ct_info1_subttl)): ?>
													<a href="" class="contact-info">
														<span class="text"><?php echo esc_html($webstrap_nav_ct_info1_ttl); ?></span>
														<span class="title"><?php echo esc_html($webstrap_nav_ct_info1_subttl); ?></span>
													</a>
												<?php endif; ?>	
											</div>
										</div>
									<?php endif; ?>
							       
								   <?php if(!empty($webstrap_nav_ct_info2_icon) || !empty($webstrap_nav_ct_info2_ttl) || !empty($webstrap_nav_ct_info2_subttl)): ?>
										<div class="widget widget_contact widget_second">
											<div class="contact-area">
												<?php if(!empty($webstrap_nav_ct_info2_icon)): ?>
													<div class="contact-icon"><i class="fa <?php echo esc_attr($webstrap_nav_ct_info2_icon); ?>"></i></div>
												<?php endif; ?>
												
												<?php if(!empty($webstrap_nav_ct_info2_ttl) || !empty($webstrap_nav_ct_info2_subttl)): ?>
													<a href="" class="contact-info">
														<span class="text"><?php echo esc_html($webstrap_nav_ct_info2_ttl); ?></span>
														<span class="title"><?php echo esc_html($webstrap_nav_ct_info2_subttl); ?></span>
													</a>
												<?php endif; ?>	
											</div>
										</div>
									<?php endif; ?>
									
							         <?php if(!empty($webstrap_nav_ct_info3_icon) || !empty($webstrap_nav_ct_info3_ttl) || !empty($webstrap_nav_ct_info3_subttl)): ?>
										<div class="widget widget_contact widget_third">
											<div class="contact-area">
												<?php if(!empty($webstrap_nav_ct_info3_icon)): ?>
													<div class="contact-icon"><i class="fa <?php echo esc_attr($webstrap_nav_ct_info3_icon); ?>"></i></div>
												<?php endif; ?>
												
												<?php if(!empty($webstrap_nav_ct_info3_ttl) || !empty($webstrap_nav_ct_info3_subttl)): ?>
													<a href="" class="contact-info">
														<span class="text"><?php echo esc_html($webstrap_nav_ct_info3_ttl); ?></span>
														<span class="title"><?php echo esc_html($webstrap_nav_ct_info3_subttl); ?></span>
													</a>
												<?php endif; ?>	
											</div>
										</div>
									<?php endif; ?>
							    </div>
								<?php } ?>
		                        <div class="header-single-widget">
		                            <div class="menu-right">
			                            <ul class="wrap-right">			                                
			                                <?php
			                                $webstrap_button_label	= get_theme_mod('button_label','Book Now');
											$webstrap_button_url	= get_theme_mod('button_url');
											$webstrap_header_cart	= get_theme_mod('header_cart','1');
											$webstrap_header_search	= get_theme_mod('header_search','on');
		                                    $header_book_hide_show 	= get_theme_mod('header_book_hide_show','1');
			                                    
	                                        if($header_book_hide_show == '1'  && !empty($webstrap_button_label)) {
			                                ?>
			                                <li class="menu-item header_btn">
			                                	<a href="<?php echo esc_url($webstrap_button_url); ?>" class="bt-primary bt-effect-1"><?php echo esc_html($webstrap_button_label); ?></a>
			                                </li>
			                                <?php } ?>
			                            </ul>                            
			                        </div>
	                            </div>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</div>
	<div class="navigator-wrapper">
	    <!-- Mobile Toggle -->
	    <div class="theme-mobile-nav d-lg-none d-block <?php echo esc_attr(specia_sticky_menu()); ?>">
	        <div class="container">
	            <div class="row">
	                <div class="col-md-12">
	                    <div class="theme-mobile-menu">
	                        <div class="headtop-mobi">
	                            <div class="headtop-shift">
	                                <a href="javascript:void(0);" class="header-sidebar-toggle open-toggle"><span></span></a>
	                                <a href="javascript:void(0);" class="header-sidebar-toggle close-button"><span></span></a>
	                                <div id="mob-h-top" class="mobi-head-top animated"></div>
	                            </div>
	                        </div>
	                        <div class="mobile-logo">
								<?php
		                        if(has_custom_logo()) {   
		                            the_custom_logo();
		                        }
		                        else { ?>
		                        	<a href="<?php echo esc_url(home_url( '/' )); ?>" class="navbar-brand">
		                        		<?php echo esc_html(get_bloginfo('name')); ?>
		                        	</a>
		                        <?php }
		                        $webstrap_description = get_bloginfo( 'description');
		                        if ($webstrap_description) : ?>
		                            <p class="site-description"><?php echo esc_html($webstrap_description); ?></p>
		                        <?php endif; ?>
	                        </div>
	                        <div class="menu-toggle-wrap">
	                            <div class="hamburger-menu">
	                                <a href="javascript:void(0);" class="menu-toggle">
	                                    <div class="top-bun"></div>
	                                    <div class="meat"></div>
	                                    <div class="bottom-bun"></div>
	                                </a>
	                            </div>
	                        </div>
	                        <div id="mobile-m" class="mobile-menu">
	                            <div class="mobile-menu-shift">
	                                <a href="javascript:void(0);" class="close-style close-menu"></a>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	    <!-- / -->

	    <!-- Top Menu -->
	    <div class="xl-nav-area d-none d-lg-block">
	        <div class="navigation <?php echo esc_attr(specia_sticky_menu()); ?>">
		        <div class="container">
		            <div class="row">
		                <div class="col-md-12">
		                    <div class="theme-menu">
		                        <nav class="menubar">
		                            <?php
		                                wp_nav_menu( 
		                                    array(  
		                                        'theme_location' => 'primary_menu',
		                                        'container'  => '',
		                                        'menu_class' => 'menu-wrap',
		                                        'fallback_cb' => 'specia_fallback_page_menu::fallback',
		                                        'walker' => new specia_nav_walker()
		                                         ) 
		                                    );
		                            ?>                               
		                        </nav>
		                        <div class="menu-right">
		                            <ul class="wrap-right">
		                            	<?php if($webstrap_header_search == 'on') { ?>
                                    	<li class="search-button">
                                            <a href="#" id="view-search-btn" class="header-search-toggle"><i class="fa fa-search"></i></a>
                                            <!-- Quik search -->
                                            <div class="view-search-btn header-search-popup">
                                                <form method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Site Search', 'webstrap' ); ?>">
                                                    <span class="screen-reader-text"><?php esc_html_e( 'Search for:', 'webstrap' ); ?></span>
                                                    <input type="search" class="search-field header-search-field" placeholder="<?php esc_attr_e( 'Type To Search', 'webstrap' ); ?>" name="s" id="popfocus" value="" autofocus>
                                                    <a href="#" class="close-style header-search-close"></a>
                                                </form>
                                            </div>
                                            <!-- / -->
                                        </li>
                                    	<?php } ?>
                                    	<?php if($webstrap_header_cart == '1') { ?>
                                        <li class="cart-wrapper">
                                            <div class="cart-icon-wrap">
                                                <a href="javascript:void(0)" id="cart"><i class="fa fa-shopping-bag"></i>
                                                <?php 
                                                if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
                                                    $count = WC()->cart->cart_contents_count;
                                                    $cart_url = wc_get_cart_url();
                                                    
                                                    if ( $count > 0 ) {
                                                    ?>
                                                         <span><?php echo esc_html( $count ); ?></span>
                                                    <?php 
                                                    }
                                                    else {
                                                        ?>
                                                        <span><?php echo esc_html_e( '0','webstrap' ); ?></span>
                                                        <?php 
                                                    }
                                                }
                                                ?>
                                                </a>
                                            </div>
                                            
                                            <!-- Shopping Cart -->
                                            <?php if ( class_exists( 'WooCommerce' ) ) { ?>
                                            <div id="header-cart" class="shopping-cart">
                                                <div class="cart-body">                                            
                                                    <?php get_template_part('woocommerce/cart/mini','cart');     ?>
                                                </div>
                                            </div>
                                            <?php } ?>
                                            <!--end shopping-cart -->
                                        </li>
                                        <?php } ?>
                                    </ul>
		                        </div>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
	    </div>
	    <!-- / -->
	</div>
</header>
<div class="clearfix"></div>
<?php 
if ( !is_page_template( 'templates/template-homepage-one.php' )) {
		specia_breadcrumbs_style(); 
	}
?>