<?php 
	$webstrap_hs_call_actions			= get_theme_mod('hide_show_call_actions','on'); 
	$webstrap_call_action_btn_lbl		= get_theme_mod('call_action_button_label');
	$webstrap_call_action_btn_link		= get_theme_mod('call_action_button_link');
	$webstrap_call_action_btn_target	= get_theme_mod('call_action_button_target');
	$call_action_img					= get_theme_mod('call_action_img',esc_url(get_template_directory_uri() .'/images/cta.jpg'));
	if($webstrap_hs_call_actions == 'on') :
?>
<section id="cta-unique" class="call-to-action-nine wow fadeInDown">
    <div class="container background-overlay">
        <div class="row padding-top-25 padding-bottom-25">
            <div class="col-md-9">
            	<div class="cta-icon-wrap mb-md-0 margin-bottom-20">
					<?php if(!empty($call_action_img)): ?>
						<div class="cta-bg"><img src="<?php echo esc_url($call_action_img); ?>"></div>
					<?php endif; ?>
                </div>
                <div class="the_content">
					<?php 
						$webstrap_aboutusquery1 = new wp_query('page_id='.get_theme_mod('call_action_page',true)); 
						if( $webstrap_aboutusquery1->have_posts() ) 
						{   while( $webstrap_aboutusquery1->have_posts() ) { $webstrap_aboutusquery1->the_post(); 
					?>
					<h6><?php the_content(); ?></h6>
                	<h2><?php the_title(); ?></h2>
					<?php } } wp_reset_postdata(); ?>
				</div>
            </div>
            <?php if($webstrap_call_action_btn_lbl) :?>
            <div class="col-md-3 text-md-right text-center">
                <a href="<?php echo esc_url($webstrap_call_action_btn_link); ?>" <?php if(($webstrap_call_action_btn_target)== 1){ echo "target='_blank'"; } ?> class="bt-primary bt-effect-1 call-btn-1"><?php echo esc_html($webstrap_call_action_btn_lbl); ?></a>
            </div>
			<?php endif; ?>				
        </div>
    </div>
</section>
<div class="clearfix"></div>
<?php endif; ?>
